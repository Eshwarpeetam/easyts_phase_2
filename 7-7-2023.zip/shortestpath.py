import heapq
def dijkstra(graph, start_node, end_node):
    distances = {node: float('inf') for node in graph}
    distances[start_node] = 0
    queue = [(0, start_node)]
    
    while queue:
        current_distance, current_node = heapq.heappop(queue)
        if current_node == end_node:
            break
        if current_distance > distances[current_node]:
            continue
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(queue, (distance, neighbor))
    if distances[end_node] == float('inf'):
        return None
    path = []
    node = end_node
    while node != start_node:
        path.append(node)
        for neighbor, weight in graph[node].items():
            if distances[node] - weight == distances[neighbor]:
                node = neighbor
                break
    path.append(start_node)
    path.reverse()
    
    return path
graph = {
    'A': {'B': 2, 'D': 4},
    'B': {'C': 7, 'D': 1},
    'C': {'F': 1},
    'D': {'E': 3},
    'E': {'F': 5, 'C': 2},
    'F': {}
}

start_node = 'A'
end_node = 'D'
shortest_path = dijkstra(graph, start_node, end_node)
if shortest_path:
    print(f"Shortest path from {start_node} to {end_node}: {' -> '.join(shortest_path)}")
else:
    print(f"There is no path from {start_node} to {end_node}.")

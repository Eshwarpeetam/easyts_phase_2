def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    else:
        pivot = arr[0]
        lesser = [x for x in arr[1:] if x <= pivot]
        greater = [x for x in arr[1:] if x > pivot]
        return quick_sort(lesser) + [pivot] + quick_sort(greater)
l = [5,3,7,2,8]
print('before sorting')
print(l)
sorted_l = quick_sort(l)
print('')
print('after sorting')
print(sorted_l)

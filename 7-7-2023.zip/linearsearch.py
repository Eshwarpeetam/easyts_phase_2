l=[1,2,3,4,5]
flag=0
k=int(input('enter search element'))
for i in range(0,len(l)):
    if(l[i]==k):
        print('element found at index',i)
        flag=1
if(flag==0):
    print('element not found')
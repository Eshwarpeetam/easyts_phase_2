l=[5,3,7,2,8]
print('before sorting')
print(l)
for i in range(0,len(l)-1):
    for j in range(0,len(l)-1-i):
        if l[j]>l[j+1]:
            temp=l[j]
            l[j]=l[j+1]
            l[j+1]=temp
print('')
print('after sorting')
print(l)
        
        
        


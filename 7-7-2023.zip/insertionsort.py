l=[5,3,7,2,8]
print('before sorting')
print(l)

for i in range(1, len(l)):
    key = l[i]
    j = i - 1
    while j >= 0 and l[j] > key:
        l[j + 1] = l[j]
        j -= 1
    l[j + 1] = key
print('')
print('afrer sorting')
print(l)




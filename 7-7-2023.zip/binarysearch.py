l=[1,2,3,4,5]
k=int(input('enter search element'))
flag=0
low=0
high=len(l)-1
while low<=high:
    mid=(low+high)//2
    if(k==l[mid]):
        print('element found')
        flag=1
        break
    elif(k<l[mid]):
        high=mid-1
    elif(k>l[mid]):
        low=mid+1
if flag==0:
    print('element not found')
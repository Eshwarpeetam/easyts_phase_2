l=[5,3,7,2,8]
print('before sorting')
print(l)
for i in range(0,len(l)-1):
    m=l[i]
    pos=i
    for j in range(i+1,len(l)):
        if(m>l[j]):
            m=l[j]
            pos=j
        else:
            m=m
            
    l[pos]=l[i]
    l[i]=m
print('')
print('afrer sorting')
print(l)
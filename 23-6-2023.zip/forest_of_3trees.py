families = {
    'charley': {'san', 'rosy'},
    'nilla': {'peps'},
    'devi': {
        'tommy': {'tony'},
        'timmy': {'hamster'},
        'tammy': {'hamster'}
    },
    'charlos': {
        'papa': 'kukka',
        'pandhi': 'topper'
    }
}

for parent, children in families.items():
    print(f"{parent} has {len(children)} kid(s):")
    if isinstance(children, set):
        children = list(children)
    for child in children:
        print(child)
    print()

class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key

def insert(root, key):
    if root is None:
        return Node(key)
    else:
        if root.val == key:
            return root
        elif root.val < key:
            root.right = insert(root.right, key)
        else:
            root.left = insert(root.left, key)
    return root

def search(root, key):
    if root is None or root.val == key:
        return root
    if root.val < key:
        return search(root.right, key)
    return search(root.left, key)

def inorder(root):
    if root:
        inorder(root.left)
        print(root.val)
        inorder(root.right)


if __name__ == "__main__":
    root = None

    num_elements = int(input("Enter the number of elements to insert: "))
    for _ in range(num_elements):
        value = int(input("Enter a value to insert: "))
        root = insert(root, value)
    print()

    print('Inorder traversal of the given tree:')
    inorder(root)
    print()

    search_key = int(input('Enter a value to search in the BST: '))
    result = search(root, search_key)
    if result is not None:
        print(f"{search_key} found in the BST.")
    else:
        print(f"{search_key} not found in the BST.")

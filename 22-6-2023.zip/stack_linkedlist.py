class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Stack:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def push(self, data):
        new_node = Node(data)
        if self.is_empty():
            self.head = new_node
        else:
            new_node.next = self.head
            self.head = new_node

    def pop(self):
        if self.is_empty():
            return None
        else:
            popped = self.head.data
            self.head = self.head.next
            return popped

    def peek(self):
        if self.is_empty():
            raise Exception("Stack is empty")
        return self.head.data

    def print_stack(self):
        if self.is_empty():
            print("Stack is empty")
        else:
            current = self.head
            while current:
                print(current.data, end=" ")
                current = current.next
            print()

obj_stack = Stack()  # Create an instance of the Stack class

while True:
    print('push <value>')
    print('pop')
    print('quit')
    do = input('Your choice: ').split()
    operation = do[0].strip().lower()

    if operation == 'push':
        obj_stack.push(int(do[1]))
    elif operation == 'pop':
        popped = obj_stack.pop()
        if popped is None:
            print('Stack is empty')
        else:
            print('Popped value:', popped)
    elif operation == 'quit':
        break

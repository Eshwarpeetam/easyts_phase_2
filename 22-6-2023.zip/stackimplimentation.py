stack = [] 

def is_empty():
    return len(stack) == 0

def push(item):
    stack.append(item)
    print(f"Pushed {item} into the stack.")

def pop():
    if is_empty():
        print("Stack is empty")
    else:
        item = stack.pop()
        print(f"Popped {item} from the stack.")

def peek():
    if is_empty():
        print("Stack is empty.")
    else:
        item = stack[-1]
        print(f"Top item: {item}")

def display():
    if is_empty():
        print("Stack is empty.")
    else:
        print(stack)

while True:
    print("\nSTACK OPERATIONS")
    print("1. Push ")
    print("2. Pop ")
    print("3. display ")
    print("4. peek ")
    print("5. Quit ")

    choice = input("Enter your choice (1-5): ")

    if choice == '1':
        item = input("Enter the item to push: ")
        push(item)
    elif choice == '2':
        pop()
    elif choice == '3':
        display()
    elif choice == '4':
        peek()
    elif choice == '5':
        print("Exiting...")
        break
    else:
        print("Invalid choice. Try again.")

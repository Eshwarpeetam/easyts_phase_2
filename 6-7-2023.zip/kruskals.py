def find(parent, v):
    if parent[v] != v:
        parent[v] = find(parent, parent[v])
    return parent[v]


def union(parent, rank, v1, v2):
    root1 = find(parent, v1)
    root2 = find(parent, v2)

    if rank[root1] < rank[root2]:
        parent[root1] = root2
    elif rank[root1] > rank[root2]:
        parent[root2] = root1
    else:
        parent[root2] = root1
        rank[root1] += 1


def kruskals(graph):
    edges = []

    for node in graph:
        for weight, dest in graph[node]:
            edges.append((weight, node, dest))
    print(edges)

    edges.sort()
    minimum_spanning_tree = []
    parent = {}
    rank = {}

    for v in graph.keys():
        parent[v] = v
        rank[v] = 0

    for edge in edges:
        weight, src, dest = edge
        root1 = find(parent, src)
        root2 = find(parent, dest)

        if root1 != root2:  # If adding this edge doesn't form a cycle
            minimum_spanning_tree.append((weight, src, dest))
            union(parent, rank, root1, root2)

    return minimum_spanning_tree


graph = {
    'A': [(28, 'B'), (10, 'F')],
    'B': [(28, 'A'), (16, 'C'), (14, 'G')],
    'C': [(16, 'B'), (12, 'D')],
    'D': [(12, 'C'), (18, 'G'), (22, 'E')],
    'E': [(25, 'F'), (24, 'G'), (22, 'D')],
    'F': [(10, 'A'), (25, 'E')],
    'G': [(24, 'E'), (18, 'D'), (14, 'B')],
}

minimum_spanning_tree = kruskals(graph)
for weight, src, dest in minimum_spanning_tree:
    print(f'{weight}:{src}--{dest}')

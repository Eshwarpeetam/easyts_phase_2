def prims(graph,start):
    parents={}
    weights={}
    queue=[]
    visited=set()
    for vertex in graph:
        weights[vertex]=9999999
    weights[start]=0
    heapq.heappush(queue,(0,start))
    print(queue)
    
      
    while len(queue) != 0:
        cur_weight,cur_node=heap.pop(0)
        if cur_node in visited:
            continue
        for weight,node in graph[cur_node]:
            if node not in visited and weight < weights[node]:
                weights[node]=weight
                parent[node]=cur_node
                heapq.heappush(queue,(weight,node))
            visited.add(cur_node)
        
    
    
graph = {
    'A': [(28,'B'), (10,'F')],
    'B': [(28,'A'), (16,'C'), (14, 'G')],
    'c': [(16,'B'), (12,'D')],
    'D': [(12,'C'), (18,'G'), (22,'E')],
    'E': [(25,'F'), (24,'G'), (22,'D')],
    'F': [(10,'A'), (25,'E')],
    'G': [(24,'E'), (18,'D'), (14,'B')],
}



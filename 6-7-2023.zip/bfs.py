graph = {
    'A': ['B'],
    'B': ['E', 'D'],
    'c': [],
    'D': ['C'],
    'E': []
}

visited = []
queue = []

def bfs(visited, graph, node):
    visited.append(node)
    queue.append(node)
    
    while queue:
        current_node = queue.pop(0)
        print(current_node, end=' ')
        
        neighbors = graph[current_node]
        for neighbor in neighbors:
            if neighbor not in visited:
                visited.append(neighbor)
                queue.append(neighbor)


start_node = '5'

print("BFS Traversal:")
bfs(visited, graph, start_node)
